package org.university.hardware;


import org.university.software.CampusCourse;
import org.university.software.OnlineCourse;
import org.university.people.Student;

import org.university.people.Professor;
import java.util.ArrayList;
import org.university.people.*;


public class Department {

	private String departmentName;
	private ArrayList<CampusCourse> campuscourses;
	private ArrayList<OnlineCourse> onlinecourses;
	private ArrayList<Student> Students;
	private ArrayList<Professor> Professors;
	private ArrayList<Staff> staff;

	public Department() {
		departmentName = "unknown";
		Students = new ArrayList<Student>();
		Professors = new ArrayList<Professor>();
		onlinecourses = new ArrayList<OnlineCourse>();
		campuscourses = new ArrayList<CampusCourse>();
		staff = new ArrayList<Staff>();
	}

	//Getter for department
	public String getDepartmentName() {
		return this.departmentName;
	}

	//Setter for department
	public void setDepartmentName(String adepartmentname) {
		this.departmentName = adepartmentname;
	}


	//Getter for Professor List 
	public ArrayList<Professor> getProfessorList(){
		return this.Professors;
	}

	//Setter for Professor list
	public void setProfessorList(Professor prof) {
		Professors.add(prof);
	}

	//Print Professor List 
	public void printProfessorList(){
		for (int i = 0; i < Professors.size(); i++) {
			System.out.println(Professors.get(i).getName());
		}
	}  


	//Getter for student List
	public ArrayList<Student> getStudentList(){
		return this.Students;
	}

	//Setter for student List
	public void setStudentList(Student s) {
		Students.add(s);
	}

	//Print Student List   
	public void printStudentList() {

		for (int i = 0; i < Students.size(); i++) {
			System.out.println(Students.get(i).getName());
		}

	}

	//Getter for Staff
	public ArrayList<Staff> getStaffList() {
		return staff;
	}

	//Setter for Staff List
	public void setStaffList(ArrayList<Staff> sf) {
		staff = sf;
	}

	//Print Staff List
	public void printStaffList() {
		for (int i = 0; i < staff.size(); i++) {
			System.out.println(staff.get(i).getName());
		}
	}

	//Getter for campuscourse
	public ArrayList<CampusCourse> getCampusCourseList() {
		return campuscourses;
	}
	//Setter for campuscourse
	public void setCampusCourseList(ArrayList<CampusCourse> campusCourses) {
		this.campuscourses = campusCourses;
	}

	//Getter for onlinecourse
	public ArrayList<OnlineCourse> getOnlineCourseList() {
		return onlinecourses;
	}

	//Setter for onlinecourse
	public void setOnlineCourseList(ArrayList<OnlineCourse> onlineCourses) {
		this.onlinecourses = onlineCourses;
	}

	//Print CampusCourse List
	public void printCourseList() {
		for (CampusCourse c: this.getCampusCourseList()) {
			System.out.println(c.getDepartment().getDepartmentName() + c.getCourseNumber() + " " + c.getName());
		}
		for (OnlineCourse o: this.getOnlineCourseList()) {				
			System.out.println(o.getDepartment().getDepartmentName() + o.getCourseNumber() + " " + o.getName());
		}
	}

	//Add Course Module
	public void addProfessor(Professor prof){
		Professors.add(prof);
		prof.setDepartment(this);
	}

	//Add Student Module
	public void addStudent(Student student){
		Students.add(student);
		student.setDepartment(this);

	}

	//Add Course Module
	public void addCourse(CampusCourse course){
		campuscourses.add(course);
		course.setDepartment(this);

	}

	//Add Staff Module
	public void addStaff(Staff stf){
		staff.add(stf);
		stf.setDepartment(this);
	}

	//Add Staff Module
	public void addCourse(OnlineCourse course){
		onlinecourses.add(course);
		course.setDepartment(this);
	}

}


