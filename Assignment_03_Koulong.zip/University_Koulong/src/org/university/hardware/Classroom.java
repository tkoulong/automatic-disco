package org.university.hardware;

import org.university.software.CampusCourse;

import java.util.ArrayList;

//Private Variables
public class Classroom {
	private String roomNumber;
	private ArrayList<CampusCourse> campuscourses;

	//Constructor
	public Classroom() {
		roomNumber = "Unknown";
		campuscourses = new ArrayList<CampusCourse>();
	}


	//Getter for Room Number
	public String getRoomNumber() {
		return this.roomNumber;
	} 

	//Setter for Room Number
	public void setRoomNumber(String newRoom) {
		roomNumber = newRoom;
	}


	//AddCourses to classRoom Module
	public void addCourse(CampusCourse aCourse) {

		boolean flag = false;

		for (CampusCourse crs : campuscourses) {

			if (crs.compareSchedules(aCourse)) {

				System.out.println(aCourse.getDepartment().getDepartmentName()

						+ aCourse.getCourseNumber() + " conflicts with "

	+ crs.getDepartment().getDepartmentName() + crs.getCourseNumber()

	+ ". Conflicting time slot " + aCourse.getConflictSlots(crs).get(0)

	+ ". " + aCourse.getDepartment().getDepartmentName()

	+ aCourse.getCourseNumber() + " course cannot be added to "

	+ roomNumber + "'s Schedule.");

				flag = true;

				break;

			}

		}

		if (!flag) {
			campuscourses.add(aCourse);
		}

	}

	//Get the meeting time slots
	private int[] getTimeSlots() {
		int[] toReturn = new int[30];
		int index = 0;
		for (int i = 100; i <= 500; i += 100) {
			for (int j = 1; j <= 6; j++) {
				toReturn[index] = i + j;
				index++;
			}
		}
		return toReturn;
	}

	//Print the schedule
	public void printSchedule() {

		int[] timeSlots = getTimeSlots();

		for (int time : timeSlots) {

			String slot = "";

			String className = "";

			for (CampusCourse crs : campuscourses) {

				if (crs.getMeetingTime(time) != "") {

					slot = crs.getMeetingTime(time);

					className = crs.getDepartment().getDepartmentName()

							+ crs.getCourseNumber() + " " + crs.getName();

					break;

				}

			}

			if (slot != "")

				System.out.println(slot + " " + className);

		}

	}



}
