package org.university.people;

import java.util.ArrayList;
import org.university.software.CampusCourse;
 import org.university.software.OnlineCourse;

//Private Variables
public abstract class Person {
protected String name;
protected ArrayList<CampusCourse> campuscourses;
protected int schedule;
protected ArrayList<OnlineCourse> onlinecourses;

//Constructor
public Person(){
	schedule = 0;
	name = "Default";
	campuscourses = new ArrayList<CampusCourse>();
	onlinecourses = new ArrayList<OnlineCourse>();
	}

//Setter for Name
public void setName(String newName){
name = newName;
}

//Getter for name
public String getName(){
return name;
}

//Getter for Schedule
public int getSchedule() {
	return schedule;
}

//Setter for Schedule
public void setSchedule(int schedule) {
	this.schedule = schedule;
}
 
//Getter for CampusCourseList
public ArrayList<CampusCourse> getCampusCourseList(){
return this.campuscourses;
}

//Setter for CampusCourseList
public void setCampusCourseList(CampusCourse aCourse) {
	campuscourses.add(aCourse);
}

//Getter for onlineCourseList
public ArrayList<OnlineCourse> getOnlineCourseList(){
	return this.onlinecourses;
}

//Setter for OnlineCourseList
public void setOnlineCourseList(OnlineCourse aCourse) {
	onlinecourses.add(aCourse);
}

//Get time Slots
private int[] getTimeSlots(){
int[] toReturn = new int[30];
int index = 0;
for(int i = 100; i <= 500; i += 100){
for(int j = 1; j <= 6; j++){
toReturn[index] = i + j;
index++;
}
}
return toReturn;
}


public boolean detectConflict(CampusCourse aCourse){
for(CampusCourse course : campuscourses){
if(course.compareSchedules(aCourse)){
ArrayList<String> conflicts = course.getConflictSlots(aCourse);
for(String conflict : conflicts){
System.out.println(aCourse.getDepartment().getDepartmentName()
+ aCourse.getCourseNumber() + " course cannot be added to "
+ name + "'s Schedule. " + aCourse.getDepartment().getDepartmentName()
+ aCourse.getCourseNumber() + " conflicts with "
+ course.getDepartment().getDepartmentName()
+ course.getCourseNumber() + ". Conflicting time slot is "
+ conflict + ".");
}
return true;
}
}
return false;
}

//Print the Schedule Method for professor 
	public void printSchedule(){
		for(int time: getTimeSlots()) {
			for(CampusCourse crs : this.campuscourses) 
				if(crs.getMeetingTime(time) != "") 
					System.out.println(crs.getMeetingTime(time)
							+ " " + crs.getDepartment().getDepartmentName()
							+ crs.getCourseNumber() + " " + crs.getName());
				}
		
				for(OnlineCourse ocrs: this.onlinecourses) {
				System.out.println(ocrs.getCourseNumber() + " " + ocrs.getName());
				}
		}

public abstract void addCourse(CampusCourse aCourse);
public abstract void addCourse(OnlineCourse aCourse);



}