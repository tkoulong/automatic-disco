package org.university.people;


import org.university.hardware.Department;
import org.university.software.CampusCourse;
import org.university.software.OnlineCourse;


public  class Student extends Person {

	//Private Variables	
	private Department dept;
	private int unitsCompleted;
	private int totalUnitsNeeded;
	private int currentEnrolled;
	private int tuitionFee;
	private int onlineUnits;
	private int campusUnits;
	//Constructor
	public Student(){
		dept = new Department();
		unitsCompleted = 0;
		totalUnitsNeeded = 0;
		currentEnrolled = 0;
		tuitionFee = 0;
		campusUnits = 0;
		onlineUnits = 0;
	}

	//Getter for Campus Units Enrolled
	public int getUnitsEnrolled() {
		return currentEnrolled;
	}

	//Setter for Campus Units Enrolled
	public void setUnitstEnrolled(int currentEnrolled) {
		this.currentEnrolled = currentEnrolled;
	}

	//Setter for Competed Units
	public void setCompletedUnits(int units){
		this.unitsCompleted = units;
	}

	//Getter for Completed Units
	public int getCompletedUnits(){
		return unitsCompleted;
	}

	//Setter for Total Units
	public void setRequiredCredits(int units){
		this.totalUnitsNeeded = units;
	}

	//Getter for Total Units
	public int getRequiredCredits(){
		return totalUnitsNeeded;
	}
	//Required to Graduate Method
	public int requiredToGraduate(){
		return (this.totalUnitsNeeded - (this.unitsCompleted + this.currentEnrolled));
	}

	//Setter for Department 
	public void setDepartment(Department deptartment){
		this.dept = getDepartment();
		//dept.addStudent(this);
	}

	//Getter for Department
	public Department getDepartment() {
		return this.dept;
	}

	//Setter for tuition fee
			public void setTuitionFee(int tuitionFee) {
				this.tuitionFee = tuitionFee;
			}
			
	//Geteer for tuition fee
			public int getTuitionFee() {
				return this.tuitionFee = calcTuitionFee();
			}
		
	//Calculating the number of campus credits
	public int campuscredit() {
		int units = 0;
		for (CampusCourse co: this.campuscourses) {
			units += co.getCreditUnits();
		}
		return units;
	}

	//Getter for tuition fee
	public int calcTuitionFee() {
		this.tuitionFee = this.campuscredit() * 300; 
		for(OnlineCourse oc: this.onlinecourses) {
			if(oc.getCreditUnits() == 3) {
				this.tuitionFee += 2000;
				break;
			}
			else if(oc.getCreditUnits() == 4) {
				this.tuitionFee += 3000;
				break;
			}
		}
		return tuitionFee;
	}

	//Add campus Course to the student
	 public void addCourse(CampusCourse cCourse) {
         if (cCourse.availableTo(this)) {                               
                 if (!campuscourses.contains(cCourse)) { 
                         if (!detectConflict(cCourse)) { 
                                 campuscourses.add(cCourse);                                 
                                 currentEnrolled += cCourse.getCreditUnits();
                                 campusUnits += cCourse.getCreditUnits();
                                 tuitionFee += (300 * cCourse.getCreditUnits());
                                 
                                 if (!cCourse.getStudentRoster().contains(this)) { 
                                         cCourse.addStudentToRoster(this);                                       
                                 }
                         }
                 }
         }
         else {
                 System.out.println(name + " can't add Campus Course " + cCourse.getDepartment().getDepartmentName() + 
                                 cCourse.getCourseNumber() + " " + cCourse.getName() + 
                                 ". Because this Campus course has enough student.");
         }
 }
 

	 public void dropCourse(CampusCourse cCourse) {
         if (campuscourses.contains(cCourse)) {
                 boolean cCreditsLessThan6 = (campusUnits - cCourse.getCreditUnits()) < 6;
                 if (!onlinecourses.isEmpty() && cCreditsLessThan6) {
                         System.out.println(name + " can't drop this CampusCourse, because this student "
                                         + "doesn't have enough campus course credit to hold the online course");
                 }
                 else {  
                                 campuscourses.remove(cCourse);                       
                                 currentEnrolled -= cCourse.getCreditUnits();
                                 campusUnits -= cCourse.getCreditUnits();
                                 tuitionFee -= (300 * cCourse.getCreditUnits());
             					cCourse.getStudentRoster().remove(this);
                 } 
         }
         else {   
                 System.out.println("The course " + cCourse.getDepartment().getDepartmentName() + cCourse.getCourseNumber() +
                                 " could not be dropped because " + getName() + " is not enrolled in " + 
                                 cCourse.getDepartment().getDepartmentName() + cCourse.getCourseNumber() +".");
         }
 }

	public void addCourse(OnlineCourse oCourse) {
        if (!onlinecourses.contains(oCourse)) {
                if (oCourse.availableTo(this)) {
                	onlinecourses.add(oCourse);
                        oCourse.addStudentToRoster(this);
                        currentEnrolled += oCourse.getCreditUnits();
                        setOnlineUnits(getOnlineUnits() + oCourse.getCreditUnits());
                        if (oCourse.getCreditUnits() == 3) 
                                tuitionFee += 2000;
                        else
                                tuitionFee += 3000;
                }
                else {
                       // System.out.println("Student " + name + " has only " + oCourse.getCreditUnits() + " on campus credits enrolled. "
                                      //  + "Should have at least 6 credits registered before registering online courses.");
                        System.out.println(name + " can't add online Course " + oCourse.getDepartment().getDepartmentName() + oCourse.getCourseNumber() + " " +oCourse.getName() +
                                        ". Because this student doesn't have enough Campus course credit.");
                }
        }
        else {
                //System.out.println("Student " + name + " has only " + oCourse.getCreditUnits() + 
                              //  " campus credits enrolled. Should have at least 6 credits registered before registering online courses.");
                System.out.println(name + " can't add online Course " + oCourse.getDepartment().getDepartmentName() + 
                                oCourse.getCourseNumber() + " " + oCourse.getName() + 
                                ". Because this student doesn't have enough Campus course credit.");
        }
}

	//Drop Course Online Course
		public void dropCourse(OnlineCourse oCourse) {
	        if (onlinecourses.contains(oCourse)) {
	                onlinecourses.remove(oCourse);
	                currentEnrolled -= oCourse.getCreditUnits();
	                setOnlineUnits(getOnlineUnits() - oCourse.getCreditUnits());
	              //  onlinecourses.remove();
					oCourse.getStudentRoster().remove(this);
	                if (oCourse.getCreditUnits() == 3)
	                        tuitionFee -= 2000;
	                else
	                        tuitionFee -= 3000;
	        }
	        else {  
	                System.out.println("The course " + oCourse.getDepartment().getDepartmentName() + oCourse.getCourseNumber() +
	                                " could not be dropped because " + getName() + " is not enrolled in " + 
	                                oCourse.getDepartment().getDepartmentName() + oCourse.getCourseNumber() +".");
	        }
	}

		public int getCampusUnits() {
			return campusUnits;
		}

		public void setCampusUnits(int campusUnits) {
			this.campusUnits = campusUnits;
		}

		public int getOnlineUnits() {
			return onlineUnits;
		}

		public void setOnlineUnits(int onlineUnits) {
			this.onlineUnits = onlineUnits;
		}
	
}