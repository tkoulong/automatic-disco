package org.university.people;


public abstract class Employee extends Person {


	public Employee() {
	}

	public abstract double earns();
	public abstract double raise(double percent);


}