package org.university.people;
import org.university.software.CampusCourse;
import org.university.software.OnlineCourse;

import java.util.ArrayList;

import org.university.hardware.Department;

public  class Staff extends Employee {
	private Department dept;
	private int hoursWorked;
	private double payRate;
	private int tuitionFee;
    protected ArrayList<CampusCourse> campusCourseList;
    protected ArrayList<OnlineCourse> onlineCourseList;
    protected ArrayList<Integer> schedule;

 
	public Staff(){
		hoursWorked = 0;
		payRate = 0.0;
		tuitionFee = 0;
		dept = new Department();
		schedule = new ArrayList<Integer>();
        campusCourseList = new ArrayList<CampusCourse>();
        onlineCourseList = new ArrayList<OnlineCourse>();
 	}

	//Setter for hoursworked
	public void setMonthlyHours(int hours){
		hoursWorked = hours;
	}

	//Getter for hoursWorked
	public int getMonthlyHours(){
		return hoursWorked;
	}

	//Setter for Department
	public void setDepartment(Department dept){
		this.dept = dept;
	}

	//Getter for Department
	public Department getDepartment(){
		return dept;
	}

	//Getter for payrate
	public double getPayRate() {
		return payRate;
	}

	//Setter for payrate
	public void setPayRate(double payRate) {
		this.payRate = payRate;
	}

	//Setter for tuition fee
	public void setTuitionFee(int tuitionFee) {
		this.tuitionFee = tuitionFee;
	}
	
//Getter for tuition fee
	public int getTuitionFee() {
		return this.tuitionFee;
	}

	//Getter for campusCourseList
public ArrayList<CampusCourse> getCampusCourseList() {
        return campusCourseList;
}

	//Setter for onlineCourseList
public ArrayList<OnlineCourse> getOnlineCourseList() {
        return onlineCourseList;
}
	//Earns
	@Override
	public double earns() {
		return (hoursWorked * this.getPayRate());
	}

	//Raise
	@Override
	public double raise(double percent) {
		return (this.payRate = payRate + ((percent/100) * payRate));
	}

	public void addCourse(CampusCourse aCourse) {
		if(this.getCampusCourseList().size() > 0){
			System.out.println(this.getCampusCourseList().get(0).getDepartment().getDepartmentName()
					+ this.getCampusCourseList().get(0).getCourseNumber() + " is removed from "
					+ this.getName() + "'s schedule(Staff can only take one class at a time). "
					+ aCourse.getDepartment().getDepartmentName() + aCourse.getCourseNumber()
					+ " has been added to " + this.getName() + "'s Schedule.");
			this.getCampusCourseList().get(0).addStudentToRoster(this);
			this.getCampusCourseList().remove(0);
		} 
		else if (this.getOnlineCourseList().size() > 0) {
            System.out.println(this.getOnlineCourseList().get(0).getDepartment().getDepartmentName()
					+ this.getOnlineCourseList().get(0).getCourseNumber() + " is removed from "
					+ this.getName() + "'s schedule(Staff can only take one class at a time). "
					+ aCourse.getDepartment().getDepartmentName() + aCourse.getCourseNumber()
					+ " has been added to " + this.getName() + "'s Schedule.");
    }
		this.getCampusCourseList().add(aCourse);
		aCourse.addStudentToRoster(this);
		tuitionFee = aCourse.getCreditUnits() * 300;
	}

	public void addCourse(OnlineCourse aCourse) {
		if(this.getOnlineCourseList().size() > 0){
			System.out.println(this.getOnlineCourseList().get(0).getDepartment().getDepartmentName()
					+ this.getOnlineCourseList().get(0).getCourseNumber() + " is removed from "
					+ this.getName() + "'s schedule(Staff can only take one class at a time). "
					+ aCourse.getDepartment().getDepartmentName() + aCourse.getCourseNumber()
					+ " has been added to " + this.getName() + "'s Schedule.");
			this.getOnlineCourseList().get(0).addStudentToRoster(this);
			this.getOnlineCourseList().remove(0);
		}
		
		else if (this.getCampusCourseList().size() > 0) {
            System.out.println(this.getCampusCourseList().get(0).getDepartment().getDepartmentName()
					+ this.getCampusCourseList().get(0).getCourseNumber() + " is removed from "
					+ this.getName() + "'s schedule(Staff can only take one class at a time). "
					+ aCourse.getDepartment().getDepartmentName() + aCourse.getCourseNumber()
					+ " has been added to " + this.getName() + "'s Schedule.");
    }
		this.getOnlineCourseList().add(aCourse);
		aCourse.addStudentToRoster(this);
		   if (aCourse.getCreditUnits() == 3)
               tuitionFee = 2000;
		   if (aCourse.getCreditUnits() == 4)
               tuitionFee = 3000;
	}
	
	/*Get time Slots
		private int[] getTimeSlots(){
		int[] toReturn = new int[30];
		int index = 0;
		for(int i = 100; i <= 500; i += 100){
		for(int j = 1; j <= 6; j++){
		toReturn[index] = i + j;
		index++;
		}
		}
		return toReturn;
		}
		
	/* //Get time Slots
	private int[] getTimeSlots(){
	int[] toReturn = new int[30];
	int index = 0;
	for(int i = 100; i <= 500; i += 100){
	for(int j = 1; j <= 6; j++){
	toReturn[index] = i + j;
	index++;
	}
	}
	return toReturn;
	}
	
	//Print the Schedule Method for professor 
			public void printSchedule(){
					for(OnlineCourse ocrs : this.onlineCourseList) {
						System.out.println(ocrs.getCourseNumber() + " " + ocrs.getName());
					}
					for(int time: getTimeSlots()) 
						for(CampusCourse crs : this.campusCourseList) {
							if(crs.getMeetingTime(time) != "")
								System.out.println(crs.getMeetingTime(time)
										+ " " + crs.getDepartment().getDepartmentName()
										+ crs.getCourseNumber() + " " + crs.getName());
							break;
						}		 
				
				}
			*/
		
	
		//Print the Schedule Method for professor 
				public void printSchedule(){
						for(OnlineCourse ocrs : this.onlineCourseList) {
							System.out.println(ocrs.getCourseNumber() + " " + ocrs.getName());
						}
						 
					}
	
}