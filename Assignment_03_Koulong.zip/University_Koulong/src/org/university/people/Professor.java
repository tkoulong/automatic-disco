package org.university.people;


import java.util.ArrayList;

import org.university.hardware.Department;
import org.university.software.CampusCourse;
import org.university.software.OnlineCourse;

public  class Professor extends Employee {
	private Department dept;
	private double salary;
	//private ArrayList<Integer> schedule;


	public Professor(){
		dept = new Department();
		salary = 0.0;	
	}

	//Getter for salary
	public double getSalary() {
		return salary;
	}

	//Setter for salary
	public void setSalary(double salary) {
		this.salary = salary;
	}

	//Setter for Department
	public void setDepartment(Department newDept){
		dept = newDept;
	}

	//Getter for Department
	public Department getDepartment(){
		return dept;
	}


	//Earn Method
	public double earns() {
		return (salary / 26);
	}

	//Raise Method
	public double raise(double percent) {
		return (this.salary = salary + (salary * percent/100.0));
	}

	//Boolean Method Detect Conflicts
	public boolean detectConflict(CampusCourse aCourse){
		for(CampusCourse course : campuscourses){
			if(course.compareSchedules(aCourse)){
				ArrayList<String> conflicts = course.getConflictSlots(aCourse);
				for(String conflict : conflicts){
					System.out.println(aCourse.getDepartment().getDepartmentName()
							+ aCourse.getCourseNumber() + " course cannot be added to "
							+ name + "'s Schedule. " + aCourse.getDepartment().getDepartmentName()
							+ aCourse.getCourseNumber() + " conflicts with "
							+ course.getDepartment().getDepartmentName()
							+ course.getCourseNumber() + ". Conflicting time slot is "
							+ conflict + ".");
				}
				return true;
			}
		}
		return false;
	}
	//Add campus course method
	public void addCourse(CampusCourse aCourse) {
		if(aCourse.getProfessorList() != null){
			System.out.println("The professor " + getName() + " cannot be assigned to this course,"
					+ " because professor " + aCourse.getProfessorList().getName()
					+ " is already assigned to the course " + aCourse.getName() + ".");
		}
		else if(!detectConflict(aCourse)){
			campuscourses.add(aCourse);
			aCourse.setProfessorList(this);
		}
	}

	//Drop CampusCourse
	public void dropCourse(CampusCourse cCourse) {
		if (campuscourses.contains(cCourse)) {
			campuscourses.remove(cCourse);                       // remove from courseList Array<Course>
			cCourse.setProfessorList(new Professor());
		} else {                                                                // if the course isn't in the Professor's courseList ArrayList<Course>
			System.out.println("The course " + cCourse.getDepartment().getDepartmentName() + cCourse.getCourseNumber() +
					" could not be dropped because " + getName() + " is not teaching " + 
					cCourse.getDepartment().getDepartmentName() + cCourse.getCourseNumber() +".");
		}
	}

	//Add online course
	public void addCourse(OnlineCourse oCourse) {

		if(oCourse.getProfessorList() != null){
			System.out.println("The professor cannot be assigned to this course"
					+ " because professor " + oCourse.getProfessorList().getName()
					+ " is already assigned to the course " + oCourse.getName() + ".");
		}
		else {
			onlinecourses.add(oCourse);
			oCourse.setProfessorList(this);

		}

	}

	//Drop OnlineCourse
	public void dropCourse(OnlineCourse oCourse) {
		if (onlinecourses.contains(oCourse)) {
			onlinecourses.remove(oCourse);                       
			oCourse.setProfessorList(new Professor());
		}
		else {                                                                
			System.out.println("The course " + oCourse.getDepartment().getDepartmentName() + oCourse.getCourseNumber() +
					" could not be dropped because " + getName() + " is not teaching " + 
					oCourse.getDepartment().getDepartmentName() + oCourse.getCourseNumber() +".");
		}
	}



	//Getting the time slots for professor
	public int[] getTimeSlots(){
		int[] toReturn = new int[50];
		int index = 0;
		for(int i = 100; i <= 500; i += 100){
			for(int j = 1; j <= 6; j++){
				toReturn[index] = i + j;
				index++;
			}
		}
		return toReturn;
	}

	//Print the Schedule Method for professor 
	public void printSchedule(){
		for(int time: getTimeSlots()) {
			for(CampusCourse crs : this.campuscourses) 
				if(crs.getMeetingTime(time) != "") 
					System.out.println(crs.getMeetingTime(time)
							+ " " + crs.getDepartment().getDepartmentName()
							+ crs.getCourseNumber() + " " + crs.getName());
		}

		for(OnlineCourse ocrs: this.onlinecourses) {
			System.out.println(ocrs.getCourseNumber() + " " + ocrs.getName());
		}
	}


}