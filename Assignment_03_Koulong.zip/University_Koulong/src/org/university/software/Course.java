package org.university.software;

import java.util.ArrayList;
import org.university.hardware.Department;
import org.university.people.Person;
import org.university.people.Professor;
import org.university.people.Staff;
import org.university.people.Student;

public abstract class Course {

	//Private Variables 
	private ArrayList<Person> roster;
	private int number;
	private String name;
	private Department department;
	private Professor professor;
	private int CreditUnits;

	//Constructors
	public Course () {
		this.name = "unknown";
		this.number = 10;
		this.department = new Department();
		this.roster = new ArrayList<Person>();
		this.professor = null;
		this.CreditUnits = 0;
	}

	//Getter for Credit Units
	public int getCreditUnits() {
		return CreditUnits;
	}

	//Setter for Credit Units
	public void setCreditUnits(int creditUnits) {
		CreditUnits = creditUnits;
	}

	//Getter of name
	public String getName() {
		return name;
	}

	//Setter of name
	public void setName(String newName) {
		name = newName;
	}

	//Getter of courseNumber
	public int getCourseNumber() {
		return number;
	}

	//setter for CourseNumber
	public void setCourseNumber(int newNum) {
		number = newNum;
	}

	//Getter for Department
	public Department getDepartment() {
		return department;
	}

	//Setter for department
	public void setDepartment(Department newDep) {
		department = newDep;
	}

	//Getter for professor List
	public Professor getProfessorList() {
		return professor;
	}

	//Setter for professor List
	public void setProfessorList(Professor professors) {
		this.professor = professors;
	}

	//Getter for studentRoster
	public ArrayList<Person> getStudentRoster() {
		return roster;
	}

	//Setter for Students
	public void setStudentRoster(Student student) {
		this.roster.add(student);
	}

	//add student to rooster
	public void addStudentToRoster(Student newStu) {
		this.roster.add(newStu);
		}

	//Add staff to a rooster
	public void addStudentToRoster(Staff newSt) {
		this.roster.add(newSt);
	}

	public abstract boolean availableTo(Student aStudent);

}