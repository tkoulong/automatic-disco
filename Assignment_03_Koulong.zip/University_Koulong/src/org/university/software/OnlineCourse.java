package org.university.software;

import org.university.people.Student;

public class OnlineCourse extends Course{

	//Available To Student Method
	public boolean availableTo(Student aStudent) {
		if (aStudent.getUnitsEnrolled() < 6) {
			System.out.println("Student " + aStudent.getName() + " has only " + 
					aStudent.getUnitsEnrolled() + " enrolled. "
					+ "Students Should have at least 6 units registered before registering for online courses.");
			return false;
		}
		else {
			return true;
		}
	}



}
