package org.university.software;

import java.util.ArrayList;
import org.university.hardware.Classroom;
import org.university.people.Student;

public class CampusCourse extends Course{

	//Private Variables
	private int MaxStudents;
	private ArrayList<Integer> schedule;
	private Classroom room;    
	private String[] Week = {"Mon", "Tue", "Wed", "Thu", "Fri"};
	private String[] Slot = {"8:00am to 9:15am", "9:30am to 10:45am", "11:00am to 12:15pm",
			"12:30pm to 1:45pm", "2:00pm to 3:15pm","3:30pm to 4:45pm"};

	//Constructor
	public CampusCourse () {
		this.MaxStudents = 1000;
		this.schedule = new ArrayList<Integer>();
		this.room = new Classroom();
	}


	//Getter for schedule
	public ArrayList<Integer> getSchedule(){
		return schedule;
	}

	//Setter for schedule
	public void setSchedule(int addNum){
		schedule.add(addNum);
	}

	//Getter for roomAssigned
	public Classroom getRoomAssigned(){
		return this.room;
	}	

	//Setter for Room Assigned
	public void setRoomAssigned(Classroom newRoom){
		room = newRoom;
		newRoom.addCourse(this);
	}

	//Getter for max students
	public int getMaxStudents () {
		return MaxStudents;
	}

	//Setter for max students
	public void setMaxCourseLimit (int stu) {
		MaxStudents = stu;
	}

	//Boolean to Compare schedules of courses to detect conflict
	public boolean compareSchedules(CampusCourse other){
		for(Integer timeSlot : other.schedule){
			if(schedule.contains(timeSlot))
				return true;
		}
		return false;
	}

	//Get Conflict Slots
	public ArrayList<String> getConflictSlots(CampusCourse aCourse){
		ArrayList<String> toReturn = new ArrayList<String>();
		for(Integer timeSlot : aCourse.schedule){
			if(schedule.contains(timeSlot))
				toReturn.add(getMeetingTime(timeSlot));
		}
		return toReturn;
	}

	//Meeting time method
	public String getMeetingTime(int timeSlot){
		if(schedule.contains(timeSlot))
			return Week[timeSlot / 100 - 1] + " " + Slot[timeSlot % 10 - 1];
		return "";
	} 

	//Print the schedule
	public void printSchedule(){
		for(int timeSlot : schedule){
			System.out.println(getMeetingTime(timeSlot) + " " + room.getRoomNumber());
		}
	}

	//Boolean to check if the course is available to a student 
	public boolean availableTo(Student aStudent) {
		if (this.getStudentRoster().size() == getMaxStudents()) {                       
			return false;
		}
		else {
			return true;
		}
	}



}
