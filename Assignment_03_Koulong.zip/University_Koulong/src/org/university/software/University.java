package org.university.software;


import org.university.hardware.Classroom;
import org.university.hardware.Department;
import org.university.people.Student;
import org.university.people.*;


import java.util.*;

public class University {


	public ArrayList<Department> departmentList;
	public ArrayList<CampusCourse> campuscourse;
	public ArrayList<OnlineCourse> onlinecourse;
	public ArrayList<Student> studentList;
	public ArrayList<Classroom> classroomList;
	public ArrayList<Staff> staffList;
	private ArrayList<Professor> professorList;

	public University() {
		this.departmentList = new ArrayList<Department>();
		this.campuscourse = new ArrayList<CampusCourse>();
		this.onlinecourse = new ArrayList<OnlineCourse>();
		this.studentList = new ArrayList<Student>();
		this.classroomList = new ArrayList<Classroom>();
		this.staffList = new ArrayList<Staff>();
		this.professorList = new ArrayList<Professor>();
	}

	//Getter for department list
	public ArrayList<Department> getDepartmentList() {
		return this.departmentList;
	}

	//Setter for Department List
	public void setDepartmentList(Department d) {
		departmentList.add(d);
	}

	//Print the department List
	public void printDepartmentList() {
		for (Department d: this.departmentList) {
			System.out.println(d.getDepartmentName());
		}
	}


	//Getter for StudentList
	public ArrayList<Student> getStudentList() {
		return this.studentList;
	}

	//Setter for StudentList
	public void setStudentList(Student s) {
		studentList.add(s);
	}

	//Print the studentList
	public void printStudentList() {
		for (Department dt: this.departmentList) {
			for (Student s: dt.getStudentList()) {
				System.out.println(s.getName());
			}
		}
	}

	//Getter for CourseList 
	public ArrayList<CampusCourse> getCampusCourseList() {
		return this.campuscourse;
	}

	//Setter for CourseList
	public void setCampusCourseList(CampusCourse c) {
		campuscourse.add(c);
	}

	//Getter for onlineCourseList 
	public ArrayList<OnlineCourse> getOnlineCourseList() {
		return this.onlinecourse;
	}

	//Setter for CourseList
	public void setOnlineCourseList(CampusCourse c) {
		campuscourse.add(c);
	}

	//Print the courseList
	public void printCourseList() {
		for (Department dt: this.departmentList) {
			for (CampusCourse c: dt.getCampusCourseList()) {
				System.out.println(c.getDepartment().getDepartmentName() + c.getCourseNumber() + " " + c.getName());
			}
		}
		for (Department dt: this.departmentList) {
			for (OnlineCourse o: dt.getOnlineCourseList()) {				
				System.out.println(o.getDepartment().getDepartmentName() + o.getCourseNumber() + " " + o.getName());
			}
		}
	}

	//Getter for Staff List
	public ArrayList<Staff> getStaffList(){
		return this.staffList;
	}

	//Setter for StaffList
	public void setStaffList(Staff st) {
		staffList.add(st);
	}

	//Print the Staff List
	public void printStaffList() {
		for (Department dt: this.departmentList) {
			for (Staff s: dt.getStaffList()) {
				System.out.println(s.getName());
			}
		}
	}

	//Getter for professorList
	public ArrayList<Professor> getProfessorList() {
		return professorList;
	}

	//Setter for professorList
	public void setProfessorList(Professor p) {
		professorList.add(p);
	}

	//Print the professorList
	public void printProfessorList() {
		for (Department dt: this.departmentList) {
			for (Professor p: dt.getProfessorList()) {
				System.out.println(p.getName());
			}
		}
	}

}

